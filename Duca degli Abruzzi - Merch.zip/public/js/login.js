import { api, avviaCielo } from './common.js';

const DOMINIO = 'ducabruzzi.eu';
const form = document.getElementById('form-login');
const messaggio = document.getElementById('messaggio');
const bottone = form.querySelector('button[type="submit"]');

avviaCielo(document.querySelector('[data-cielo]'));

const regole = {
  nome: (v) => (/^[\p{L}][\p{L}' .-]{0,49}$/u.test(v.trim()) ? '' : 'Inserisci il tuo nome.'),
  cognome: (v) => (/^[\p{L}][\p{L}' .-]{0,49}$/u.test(v.trim()) ? '' : 'Inserisci il tuo cognome.'),
  classe: (v) => (/^[1-5][A-Z]{1,5}$/.test(v.toUpperCase().replace(/[\s^°ª.\-]/g, '')) ? '' : 'Scrivi la classe come numero + sezione, es. 3B.'),
  email: (v) => {
    const e = v.trim().toLowerCase();
    if (!e) return 'Inserisci la tua mail istituzionale.';
    if (!e.endsWith('@' + DOMINIO)) return `Deve essere la mail della scuola (@${DOMINIO}).`;
    return /^[a-z0-9](?:[a-z0-9._%+-]{0,62}[a-z0-9])?@/.test(e) ? '' : 'Controlla di aver scritto bene la mail.';
  }
};

function mostraErrore(nome, testo) {
  const campo = form.elements[nome].closest('.campo');
  campo.classList.toggle('ha-errore', Boolean(testo));
  campo.querySelector('.campo__errore').textContent = testo;
  form.elements[nome].setAttribute('aria-invalid', testo ? 'true' : 'false');
}

function valida() {
  let primoErrato = null;
  for (const [nome, regola] of Object.entries(regole)) {
    const errore = regola(form.elements[nome].value);
    mostraErrore(nome, errore);
    if (errore && !primoErrato) primoErrato = form.elements[nome];
  }
  return primoErrato;
}

// Validazione mentre si scrive (solo dopo che il campo è stato toccato)
for (const nome of Object.keys(regole)) {
  const input = form.elements[nome];
  input.addEventListener('blur', () => { if (input.value) mostraErrore(nome, regole[nome](input.value)); });
  input.addEventListener('input', () => {
    if (input.closest('.campo').classList.contains('ha-errore')) mostraErrore(nome, regole[nome](input.value));
  });
}
form.elements.classe.addEventListener('input', (e) => { e.target.value = e.target.value.toUpperCase(); });

form.addEventListener('submit', async (evento) => {
  evento.preventDefault();
  messaggio.textContent = '';
  const errato = valida();
  if (errato) { errato.focus(); return; }

  bottone.disabled = true;
  bottone.classList.add('in-corso');
  try {
    await api('/api/login', {
      metodo: 'POST',
      reindirizzaSe401: false,
      dati: {
        nome: form.elements.nome.value,
        cognome: form.elements.cognome.value,
        classe: form.elements.classe.value,
        email: form.elements.email.value
      }
    });
    window.location.href = '/';
  } catch (err) {
    messaggio.textContent = err.message;
    const errori = err.dettagli?.errori || {};
    for (const [nome, testo] of Object.entries(errori)) mostraErrore(nome, testo);
    bottone.disabled = false;
    bottone.classList.remove('in-corso');
  }
});
