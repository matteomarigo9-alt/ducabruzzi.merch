import { api, avviaTestata, osservaComparse, immagineProdotto, sfondoPer, euro, escapeHtml, iniziali, toast } from './common.js';

const MAX_QUANTITA = 20;

const el = {
  catalogo: document.getElementById('catalogo'),
  righe: document.getElementById('righe'),
  vuoto: document.getElementById('vuoto'),
  totale: document.getElementById('totale'),
  conteggio: document.getElementById('conteggio'),
  note: document.getElementById('note'),
  invia: document.getElementById('invia'),
  barra: document.getElementById('barra-mobile'),
  barraPezzi: document.getElementById('barra-pezzi'),
  barraTotale: document.getElementById('barra-totale'),
  listaMiei: document.getElementById('lista-miei'),
  dlgConferma: document.getElementById('dlg-conferma'),
  dlgSuccesso: document.getElementById('dlg-successo'),
  conferma: document.getElementById('conferma')
};

let prodotti = [];
let carrello = [];      // [{ prodottoId, colore, taglia, quantita }]
let chiaveArchivio = 'duca-carrello';
let preordiniAperti = true;

const trova = (id) => prodotti.find((p) => p.id === id);
const nomeCompleto = (p) => (p.variante ? `${p.nome} – ${p.variante}` : p.nome);
const limita = (n) => Math.min(MAX_QUANTITA, Math.max(1, Math.round(Number(n)) || 1));

/* ---------- Salvataggio del carrello nel browser (sopravvive al ricaricamento) ---------- */
function salva() {
  try { localStorage.setItem(chiaveArchivio, JSON.stringify({ carrello, note: el.note.value })); } catch { /* archiviazione non disponibile */ }
}
function ripristina() {
  try {
    const dati = JSON.parse(localStorage.getItem(chiaveArchivio) || 'null');
    if (!dati) return;
    carrello = (dati.carrello || []).filter((r) => {
      const p = trova(r.prodottoId);
      return p && p.colori.some((c) => c.id === r.colore) && p.taglie.includes(r.taglia);
    }).map((r) => ({ ...r, quantita: limita(r.quantita) }));
    el.note.value = dati.note || '';
  } catch { carrello = []; }
}

/* ---------- Schede articolo ---------- */
function stepperHtml(valore, etichetta, piccolo = false) {
  return `
    <div class="stepper${piccolo ? ' stepper--piccolo' : ''}">
      <button type="button" data-passo="-1" aria-label="Diminuisci quantità">−</button>
      <input type="number" inputmode="numeric" min="1" max="${MAX_QUANTITA}" value="${valore}" aria-label="${escapeHtml(etichetta)}">
      <button type="button" data-passo="1" aria-label="Aumenta quantità">+</button>
    </div>`;
}

function collegaStepper(radice, alCambio) {
  const input = radice.querySelector('input');
  radice.querySelectorAll('[data-passo]').forEach((b) => b.addEventListener('click', () => {
    input.value = limita(Number(input.value) + Number(b.dataset.passo));
    alCambio(Number(input.value));
  }));
  input.addEventListener('change', () => { input.value = limita(input.value); alCambio(Number(input.value)); });
}

function renderCatalogo() {
  el.catalogo.innerHTML = prodotti.map((p, i) => {
    const primo = p.colori[0];
    const unica = p.taglie.length === 1;
    return `
      <article class="articolo" id="${p.id}" data-id="${p.id}" data-reveal style="--ritardo:${(i % 2) * 0.1}s">
        <div class="articolo__media" style="--sfondo:${sfondoPer(primo.hex)}">
          <div class="articolo__img">${immagineProdotto(p, primo.id)}</div>
          <span class="articolo__prezzo">${euro(p.prezzo)}</span>
        </div>
        <div class="articolo__corpo">
          <div class="articolo__titolo">
            <h2>${escapeHtml(p.nome)}</h2>
            ${p.variante ? `<span class="articolo__variante">${escapeHtml(p.variante)}</span>` : ''}
          </div>
          <fieldset class="scelta" data-scelta="colore">
            <legend>Colore: <b data-nome-colore>${escapeHtml(primo.nome)}</b></legend>
            <div class="opzioni">
              ${p.colori.map((c, j) => `
                <label title="${escapeHtml(c.nome)}">
                  <input type="radio" name="colore-${p.id}" value="${c.id}" ${j === 0 ? 'checked' : ''}>
                  <span class="swatch" style="--c:${c.hex}"></span>
                  <span class="sr-only">${escapeHtml(c.nome)}</span>
                </label>`).join('')}
            </div>
          </fieldset>
          <fieldset class="scelta" data-scelta="taglia">
            <legend>Taglia${unica ? '' : ': <b data-nome-taglia>scegli</b>'}</legend>
            <div class="opzioni">
              ${p.taglie.map((t) => `
                <label>
                  <input type="radio" name="taglia-${p.id}" value="${escapeHtml(t)}" ${unica ? 'checked' : ''}>
                  <span class="chip">${escapeHtml(t)}</span>
                </label>`).join('')}
            </div>
          </fieldset>
          <div class="articolo__azioni">
            ${stepperHtml(1, `Quantità ${nomeCompleto(p)}`)}
            <button type="button" class="btn" data-aggiungi ${preordiniAperti ? '' : 'disabled'}>Aggiungi</button>
          </div>
        </div>
      </article>`;
  }).join('');

  el.catalogo.querySelectorAll('.articolo').forEach((scheda) => {
    const p = trova(scheda.dataset.id);
    const media = scheda.querySelector('.articolo__media');
    const img = scheda.querySelector('.articolo__img');
    const sceltaTaglia = scheda.querySelector('[data-scelta="taglia"]');
    const quantita = scheda.querySelector('.articolo__azioni input');

    scheda.querySelectorAll(`input[name="colore-${p.id}"]`).forEach((r) => r.addEventListener('change', () => {
      const c = p.colori.find((x) => x.id === r.value);
      scheda.querySelector('[data-nome-colore]').textContent = c.nome;
      media.style.setProperty('--sfondo', sfondoPer(c.hex));
      img.innerHTML = immagineProdotto(p, c.id);
      img.classList.remove('cambio');
      void img.offsetWidth;
      img.classList.add('cambio');
    }));

    scheda.querySelectorAll(`input[name="taglia-${p.id}"]`).forEach((r) => r.addEventListener('change', () => {
      sceltaTaglia.classList.remove('manca');
      const nome = scheda.querySelector('[data-nome-taglia]');
      if (nome) nome.textContent = r.value;
    }));

    collegaStepper(scheda.querySelector('.articolo__azioni .stepper'), () => {});

    scheda.querySelector('[data-aggiungi]').addEventListener('click', () => {
      const colore = scheda.querySelector(`input[name="colore-${p.id}"]:checked`)?.value;
      const taglia = scheda.querySelector(`input[name="taglia-${p.id}"]:checked`)?.value;
      if (!taglia) {
        sceltaTaglia.classList.remove('manca');
        void sceltaTaglia.offsetWidth;
        sceltaTaglia.classList.add('manca');
        toast('Scegli prima una taglia', { errore: true });
        return;
      }
      aggiungi(p, colore, taglia, limita(quantita.value));
      quantita.value = 1;
    });
  });
}

/* ---------- Carrello ---------- */
function aggiungi(p, colore, taglia, quantita) {
  const esistente = carrello.find((r) => r.prodottoId === p.id && r.colore === colore && r.taglia === taglia);
  if (esistente) {
    const prima = esistente.quantita;
    esistente.quantita = limita(prima + quantita);
    if (esistente.quantita === prima) {
      toast(`Massimo ${MAX_QUANTITA} pezzi per lo stesso capo, colore e taglia`, { errore: true });
      return;
    }
  } else {
    carrello.push({ prodottoId: p.id, colore, taglia, quantita });
  }
  const nomeColore = p.colori.find((c) => c.id === colore).nome;
  toast(`Aggiunto: ${nomeCompleto(p)} · ${nomeColore} · ${taglia}`);
  el.conteggio.classList.remove('salta');
  void el.conteggio.offsetWidth;
  el.conteggio.classList.add('salta');
  renderCarrello();
}

const totaleCarrello = () => carrello.reduce((s, r) => s + r.quantita * trova(r.prodottoId).prezzo, 0);
const pezziCarrello = () => carrello.reduce((s, r) => s + r.quantita, 0);

function renderCarrello() {
  const totale = totaleCarrello();
  const pezzi = pezziCarrello();

  el.righe.innerHTML = carrello.map((r, i) => {
    const p = trova(r.prodottoId);
    const c = p.colori.find((x) => x.id === r.colore);
    return `
      <li class="riga" data-indice="${i}">
        <div class="riga__img">${immagineProdotto(p, c.id)}</div>
        <div>
          <div class="riga__nome">${escapeHtml(nomeCompleto(p))}</div>
          <div class="riga__dettagli">${escapeHtml(c.nome)} · ${escapeHtml(r.taglia)} · ${euro(p.prezzo)} cad.</div>
          <div class="riga__fondo">${stepperHtml(r.quantita, `Quantità ${nomeCompleto(p)} ${c.nome} ${r.taglia}`, true)}</div>
        </div>
        <div class="riga__destra">
          <span class="riga__prezzo">${euro(p.prezzo * r.quantita)}</span>
          <button type="button" class="riga__rimuovi" data-rimuovi>Rimuovi</button>
        </div>
      </li>`;
  }).join('');

  el.righe.querySelectorAll('.riga').forEach((li) => {
    const i = Number(li.dataset.indice);
    collegaStepper(li.querySelector('.stepper'), (q) => { carrello[i].quantita = q; renderCarrello(); });
    li.querySelector('[data-rimuovi]').addEventListener('click', () => { carrello.splice(i, 1); renderCarrello(); });
  });

  el.vuoto.hidden = carrello.length > 0;
  el.totale.textContent = euro(totale);
  el.conteggio.textContent = pezzi;
  el.invia.disabled = !carrello.length || !preordiniAperti;
  el.barraPezzi.textContent = `${pezzi} ${pezzi === 1 ? 'pezzo' : 'pezzi'}`;
  el.barraTotale.textContent = euro(totale);
  el.barra.classList.toggle('visibile', carrello.length > 0);
  salva();
}

el.note.addEventListener('input', salva);

/* ---------- Invio ---------- */
document.querySelectorAll('dialog [data-chiudi]').forEach((b) => b.addEventListener('click', () => b.closest('dialog').close()));

el.invia.addEventListener('click', () => {
  document.getElementById('dlg-righe').innerHTML = carrello.map((r) => {
    const p = trova(r.prodottoId);
    const c = p.colori.find((x) => x.id === r.colore);
    return `<li><span>${r.quantita} × ${escapeHtml(nomeCompleto(p))}<br><small class="muto">${escapeHtml(c.nome)} · ${escapeHtml(r.taglia)}</small></span><span>${euro(p.prezzo * r.quantita)}</span></li>`;
  }).join('');
  document.getElementById('dlg-totale').textContent = euro(totaleCarrello());
  el.dlgConferma.showModal();
});

el.conferma.addEventListener('click', async () => {
  el.conferma.disabled = true;
  el.conferma.classList.add('in-corso');
  try {
    const { ordine } = await api('/api/ordini', {
      metodo: 'POST',
      dati: { righe: carrello, note: el.note.value }
    });
    carrello = [];
    el.note.value = '';
    renderCarrello();
    el.dlgConferma.close();
    document.getElementById('dlg-successo-testo').textContent =
      `Il tuo preordine n. ${ordine.id} da ${euro(ordine.totale)} è stato registrato. Lo trovi qui sotto in “I tuoi preordini”.`;
    el.dlgSuccesso.showModal();
    caricaMiei();
  } catch (err) {
    toast(err.message, { errore: true });
  } finally {
    el.conferma.disabled = false;
    el.conferma.classList.remove('in-corso');
  }
});

el.dlgSuccesso.addEventListener('close', () => {
  document.getElementById('miei').scrollIntoView({ behavior: 'smooth' });
});

/* ---------- I miei preordini ---------- */
const formatoData = new Intl.DateTimeFormat('it-IT', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });

async function caricaMiei() {
  let ordini;
  try {
    ordini = await api('/api/ordini/miei');
  } catch (err) {
    el.listaMiei.innerHTML = `<p class="miei__vuoto">${escapeHtml(err.message)}</p>`;
    return;
  }
  if (!ordini.length) {
    el.listaMiei.innerHTML = '<p class="miei__vuoto">Non hai ancora inviato preordini.</p>';
    return;
  }
  el.listaMiei.innerHTML = ordini.map((o) => `
    <article class="scheda-ordine${o.stato === 'annullato' ? ' scheda-ordine--annullato' : ''}">
      <div class="scheda-ordine__testa">
        <div>
          <h3>Preordine n. ${o.id}</h3>
          <time datetime="${escapeHtml(o.creatoIl)}">${formatoData.format(new Date(o.creatoIl))}</time>
        </div>
        <span class="stato stato--${escapeHtml(o.stato)}">${escapeHtml(o.stato)}</span>
      </div>
      <ul>
        ${o.righe.map((r) => `<li><span>${r.quantita} × ${escapeHtml(r.prodotto)} · ${escapeHtml(r.colore)} · ${escapeHtml(r.taglia)}</span><span>${euro(r.prezzo * r.quantita)}</span></li>`).join('')}
      </ul>
      ${o.note ? `<p class="note">“${escapeHtml(o.note)}”</p>` : ''}
      <div class="scheda-ordine__fondo">
        <strong>${euro(o.totale)}</strong>
        ${o.stato === 'ricevuto' ? `<button type="button" class="btn btn--fantasma btn--piccolo" data-annulla="${o.id}">Annulla</button>` : ''}
      </div>
    </article>`).join('');

  el.listaMiei.querySelectorAll('[data-annulla]').forEach((b) => b.addEventListener('click', async () => {
    if (!window.confirm(`Vuoi davvero annullare il preordine n. ${b.dataset.annulla}?`)) return;
    try {
      await api(`/api/ordini/${b.dataset.annulla}`, { metodo: 'DELETE' });
      toast('Preordine annullato');
      caricaMiei();
    } catch (err) {
      toast(err.message, { errore: true });
    }
  }));
}

/* ---------- Avvio ---------- */
async function avvia() {
  try {
    const [utente, catalogo] = await Promise.all([avviaTestata({ sempreSolida: true }), api('/api/prodotti')]);
    prodotti = catalogo.prodotti;
    preordiniAperti = utente.preordiniAperti;
    chiaveArchivio = `duca-carrello:${utente.email}`;

    const chi = document.getElementById('chi-ordina');
    chi.innerHTML = `<span class="utente__avatar" aria-hidden="true">${escapeHtml(iniziali(utente))}</span>
      <span>Stai ordinando come <strong>${escapeHtml(utente.nome)} ${escapeHtml(utente.cognome)}</strong> · ${escapeHtml(utente.classe)} · ${escapeHtml(utente.email)}</span>`;
    chi.hidden = false;
    document.getElementById('avviso-chiuso').hidden = preordiniAperti;

    renderCatalogo();
    ripristina();
    renderCarrello();
    osservaComparse();

    // Arrivo da un link "Preordina" della home (es. preordini.html#tshirt)
    if (location.hash) document.getElementById(location.hash.slice(1))?.scrollIntoView({ block: 'center' });
  } catch (err) {
    el.catalogo.innerHTML = `<p class="caricamento">${escapeHtml(err.message)}</p>`;
  }
  caricaMiei();
}

avvia();
