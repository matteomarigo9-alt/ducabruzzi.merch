import { api, euro, escapeHtml } from './common.js';

// Un colore per ogni taglia, come nella legenda del modulo originale
const COLORI_TAGLIE = {
  XS: '#3b5bdb', S: '#e03131', M: '#f08c00', L: '#2f9e44', XL: '#9c36b5', XXL: '#1098ad', '3XL': '#d6336c',
  'Taglia unica': '#3b5bdb'
};

const accesso = document.getElementById('accesso');
const pannello = document.getElementById('pannello');
const form = document.getElementById('form-admin');
const messaggio = document.getElementById('messaggio-admin');
let dati = null;

async function avvia() {
  const { admin } = await api('/api/admin/stato', { reindirizzaSe401: false });
  if (admin) mostraPannello(); else accesso.hidden = false;
}

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = form.querySelector('button');
  btn.classList.add('in-corso');
  messaggio.textContent = '';
  try {
    await api('/api/admin/login', { metodo: 'POST', dati: { password: form.password.value }, reindirizzaSe401: false });
    accesso.hidden = true;
    mostraPannello();
  } catch (err) {
    messaggio.textContent = err.message;
  } finally {
    btn.classList.remove('in-corso');
  }
});

document.getElementById('esci-admin').addEventListener('click', async () => {
  await api('/api/admin/logout', { metodo: 'POST', dati: {}, reindirizzaSe401: false }).catch(() => {});
  location.reload();
});
document.getElementById('aggiorna').addEventListener('click', () => carica());

document.querySelectorAll('[data-scheda]').forEach((b) => b.addEventListener('click', () => {
  document.querySelectorAll('[data-scheda]').forEach((x) => x.setAttribute('aria-selected', String(x === b)));
  document.getElementById('scheda-grafici').hidden = b.dataset.scheda !== 'grafici';
  document.getElementById('scheda-ordini').hidden = b.dataset.scheda !== 'ordini';
}));

document.getElementById('cerca').addEventListener('input', (e) => renderOrdini(e.target.value));

async function mostraPannello() {
  pannello.hidden = false;
  await carica();
}

async function carica() {
  try {
    dati = await api('/api/admin/riepilogo', { reindirizzaSe401: false });
  } catch (err) {
    if (err.stato === 401) { location.reload(); return; }
    document.getElementById('kpi').innerHTML = `<p>${escapeHtml(err.message)}</p>`;
    return;
  }
  renderKpi();
  renderGrafici();
  renderOrdini(document.getElementById('cerca').value);
}

function renderKpi() {
  const k = dati.kpi;
  document.getElementById('kpi').innerHTML = [
    ['Preordini', k.ordini], ['Pezzi', k.pezzi], ['Studenti', k.studenti], ['Incasso previsto', euro(k.incasso)]
  ].map(([t, v]) => `<div class="kpi__box"><span>${t}</span><strong>${v}</strong></div>`).join('');
}

/** Grafico a barre raggruppate: gruppi = colori, barre = taglie. */
function graficoSvg(p) {
  const W = 520, H = 220, sx = 28, base = 180, alto = 14;
  const max = Math.max(1, ...p.colori.flatMap((c) => p.taglie.map((t) => p.matrice[c.id]?.[t] || 0)));
  const passoY = max <= 5 ? 1 : Math.ceil(max / 5);
  const larGruppo = (W - sx) / p.colori.length;
  const larBarra = Math.min(10, (larGruppo - 10) / p.taglie.length);
  let svg = '';

  for (let v = 0; v <= max; v += passoY) {
    const y = base - (v / max) * (base - alto);
    svg += `<line x1="${sx}" x2="${W}" y1="${y}" y2="${y}" stroke="rgba(20,32,26,.1)"/><text x="${sx - 6}" y="${y + 3}" text-anchor="end">${v}</text>`;
  }
  p.colori.forEach((c, gi) => {
    const x0 = sx + gi * larGruppo + (larGruppo - larBarra * p.taglie.length) / 2;
    p.taglie.forEach((t, ti) => {
      const q = p.matrice[c.id]?.[t] || 0;
      if (!q) return;
      const h = (q / max) * (base - alto);
      svg += `<rect class="barra" x="${x0 + ti * larBarra}" y="${base - h}" width="${larBarra - 1.5}" height="${h}" rx="1.5" fill="${COLORI_TAGLIE[t] || '#888'}" style="animation-delay:${(gi * 0.04).toFixed(2)}s"><title>${escapeHtml(c.nome)} · ${escapeHtml(t)}: ${q}</title></rect>`;
    });
    const parole = c.nome.toUpperCase().split(' ');
    svg += `<text x="${sx + gi * larGruppo + larGruppo / 2}" y="${base + 14}" text-anchor="middle">${parole.map((w, i) => `<tspan x="${sx + gi * larGruppo + larGruppo / 2}" dy="${i ? 11 : 0}">${escapeHtml(w)}</tspan>`).join('')}</text>`;
  });
  return `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="Grafico preordini ${escapeHtml(p.nome)}">${svg}</svg>`;
}

function tabellaMatrice(p) {
  const totaleTaglia = (t) => p.colori.reduce((s, c) => s + (p.matrice[c.id]?.[t] || 0), 0);
  return `
    <div class="tabella-wrap"><table class="tabella">
      <thead><tr><th>Colore</th>${p.taglie.map((t) => `<th class="num">${escapeHtml(t)}</th>`).join('')}<th class="num">Tot.</th></tr></thead>
      <tbody>
        ${p.colori.map((c) => {
          const riga = p.taglie.map((t) => p.matrice[c.id]?.[t] || 0);
          const tot = riga.reduce((a, b) => a + b, 0);
          return `<tr><td>${escapeHtml(c.nome)}</td>${riga.map((q) => `<td class="num${q ? '' : ' zero'}">${q}</td>`).join('')}<td class="num"><b>${tot}</b></td></tr>`;
        }).join('')}
        <tr class="totale"><td>Totale</td>${p.taglie.map((t) => `<td class="num">${totaleTaglia(t)}</td>`).join('')}<td class="num">${p.totalePezzi}</td></tr>
      </tbody>
    </table></div>`;
}

function renderGrafici() {
  document.getElementById('scheda-grafici').innerHTML = dati.prodotti.map((p) => `
    <article class="grafico">
      <h3>${escapeHtml(p.nome)}${p.variante ? ` ${escapeHtml(p.variante.toUpperCase())}` : ''} ${euro(p.prezzo)}</h3>
      <p class="grafico__sotto">${p.totalePezzi} ${p.totalePezzi === 1 ? 'pezzo' : 'pezzi'} preordinati</p>
      <div class="legenda">${p.taglie.map((t) => `<span><i style="--c:${COLORI_TAGLIE[t] || '#888'}"></i>${escapeHtml(t)}</span>`).join('')}</div>
      ${graficoSvg(p)}
      ${tabellaMatrice(p)}
    </article>`).join('');
}

const formatoData = new Intl.DateTimeFormat('it-IT', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });

function renderOrdini(filtro = '') {
  const f = filtro.trim().toLowerCase();
  const ordini = dati.ordini.filter((o) => !f || `${o.nome} ${o.cognome} ${o.classe} ${o.email}`.toLowerCase().includes(f));
  document.getElementById('corpo-ordini').innerHTML = ordini.length ? ordini.map((o) => `
    <tr class="${o.stato === 'annullato' ? 'annullato' : ''}">
      <td>${o.id}</td>
      <td>${formatoData.format(new Date(o.creatoIl))}</td>
      <td><strong>${escapeHtml(o.cognome)} ${escapeHtml(o.nome)}</strong><br><small class="muto">${escapeHtml(o.email)}</small></td>
      <td>${escapeHtml(o.classe)}</td>
      <td>${o.righe.map((r) => `${r.quantita} × ${escapeHtml(r.prodotto)} · ${escapeHtml(r.colore)} · ${escapeHtml(r.taglia)}`).join('<br>')}${o.note ? `<br><em class="muto">Note: ${escapeHtml(o.note)}</em>` : ''}</td>
      <td class="num">${euro(o.totale)}</td>
      <td>${escapeHtml(o.stato)}</td>
      <td class="azioni">
        ${o.stato === 'ricevuto'
          ? `<button type="button" class="btn btn--fantasma btn--piccolo" data-azione="annulla" data-id="${o.id}">Annulla</button>`
          : `<button type="button" class="btn btn--fantasma btn--piccolo" data-azione="ripristina" data-id="${o.id}">Ripristina</button>`}
        <button type="button" class="btn btn--piccolo btn--pericolo" data-azione="elimina" data-id="${o.id}">Elimina</button>
      </td>
    </tr>`).join('') : '<tr><td colspan="8" class="muto">Nessun preordine trovato.</td></tr>';
}

// Azioni sui preordini (un solo ascoltatore per tutta la tabella)
document.getElementById('corpo-ordini').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-azione]');
  if (!btn) return;
  const id = btn.dataset.id;
  const o = dati.ordini.find((x) => String(x.id) === id);
  const chi = o ? `${o.nome} ${o.cognome} (${o.classe})` : '';
  const azione = btn.dataset.azione;

  const conferme = {
    annulla: `Annullare il preordine n. ${id} di ${chi}?\n\nResterà nell'elenco come "annullato" ma non verrà più contato nei totali. Potrai ripristinarlo.`,
    ripristina: `Ripristinare il preordine n. ${id} di ${chi}?\n\nTornerà a essere contato nei totali.`,
    elimina: `ELIMINARE DEFINITIVAMENTE il preordine n. ${id} di ${chi}?\n\nVerrà cancellato dal database e non si potrà recuperare.`
  };
  if (!window.confirm(conferme[azione])) return;

  btn.disabled = true;
  try {
    if (azione === 'elimina') {
      await api(`/api/admin/ordini/${id}`, { metodo: 'DELETE', reindirizzaSe401: false });
    } else {
      await api(`/api/admin/ordini/${id}/stato`, {
        metodo: 'POST',
        reindirizzaSe401: false,
        dati: { stato: azione === 'annulla' ? 'annullato' : 'ricevuto' }
      });
    }
    await carica();
  } catch (err) {
    if (err.stato === 401) { location.reload(); return; }
    window.alert(err.message);
    btn.disabled = false;
  }
});

avvia().catch(() => { accesso.hidden = false; });
