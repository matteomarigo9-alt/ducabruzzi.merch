import { api, avviaTestata, avviaCielo, osservaComparse, immagineProdotto, sfondoPer, euro, escapeHtml, riduciMovimento } from './common.js';

avviaTestata().catch(() => {});
document.querySelectorAll('[data-cielo]').forEach((c) => avviaCielo(c));

/* ---------- Manifesto: le parole si accendono man mano che si scorre ---------- */
const manifesto = document.querySelector('[data-manifesto]');
const parole = manifesto.textContent.trim().split(/\s+/).map((p) => {
  const oro = p.startsWith('*');
  const testo = p.replace(/\*/g, '');
  return `<span class="parola${oro ? ' oro' : ''}">${escapeHtml(testo)}</span>`;
});
manifesto.innerHTML = parole.join(' ');
const spanParole = [...manifesto.querySelectorAll('.parola')];

/* ---------- Effetti legati allo scroll (un solo requestAnimationFrame) ---------- */
const hero = document.querySelector('[data-hero]');
let inAttesa = false;

function aggiornaScroll() {
  inAttesa = false;
  const h = window.innerHeight;

  // Hero: lo stemma sale e sfuma
  if (!riduciMovimento()) {
    const y = Math.min(window.scrollY, h);
    hero.style.transform = `translateY(${y * 0.35}px) scale(${1 - y / h * 0.08})`;
    hero.style.opacity = String(1 - y / (h * 0.85));
  }

  // Manifesto
  const r = manifesto.getBoundingClientRect();
  const progresso = Math.min(1, Math.max(0, (h * 0.85 - r.top) / (r.height + h * 0.35)));
  const accese = Math.round(progresso * spanParole.length);
  spanParole.forEach((s, i) => s.classList.toggle('accesa', i < accese));

  // Parallasse leggera delle immagini dei prodotti
  if (!riduciMovimento()) {
    document.querySelectorAll('.prodotto__img').forEach((img) => {
      const box = img.parentElement.getBoundingClientRect();
      if (box.bottom < 0 || box.top > h) return;
      const centro = (box.top + box.height / 2 - h / 2) / h;
      img.style.setProperty('--parallasse', `${(centro * -28).toFixed(1)}px`);
    });
  }
}

window.addEventListener('scroll', () => {
  if (!inAttesa) { inAttesa = true; requestAnimationFrame(aggiornaScroll); }
}, { passive: true });
window.addEventListener('resize', aggiornaScroll);
aggiornaScroll();

/* ---------- Vetrina prodotti ---------- */
async function caricaVetrina() {
  const contenitore = document.getElementById('vetrina');
  let catalogo;
  try {
    catalogo = await api('/api/prodotti');
  } catch (err) {
    contenitore.innerHTML = `<p class="caricamento">${escapeHtml(err.message)}</p>`;
    return;
  }

  contenitore.innerHTML = catalogo.categorie.map((cat, i) => {
    const prodotti = catalogo.prodotti.filter((p) => p.categoria === cat.id);
    const principale = prodotti[0];
    const varianti = prodotti.map((p) => p.variante).filter(Boolean);
    const taglie = principale.taglie.length > 1
      ? `Taglie ${principale.taglie[0]}–${principale.taglie.at(-1)}`
      : principale.taglie[0];
    const primo = principale.colori[0];

    return `
      <article class="prodotto" data-categoria="${cat.id}">
        <div class="prodotto__media" style="--sfondo:${sfondoPer(primo.hex)}">
          <div class="prodotto__img">${immagineProdotto(principale, primo.id)}</div>
          <span class="prodotto__numero" aria-hidden="true">0${i + 1}</span>
        </div>
        <div class="prodotto__testo">
          <p class="sovratitolo">0${i + 1} — ${escapeHtml(cat.titolo)}</p>
          <h3>${escapeHtml(cat.titolo)}</h3>
          <p class="descr">${escapeHtml(cat.testo)}</p>
          ${varianti.length ? `<ul class="prodotto__varianti" aria-label="Varianti">${varianti.map((v) => `<li>${escapeHtml(v)}</li>`).join('')}</ul>` : ''}
          <div>
            <div class="pallini" role="group" aria-label="Colori disponibili">
              ${principale.colori.map((c, j) => `
                <button type="button" class="pallino" style="--c:${c.hex}" data-colore="${c.id}"
                        aria-pressed="${j === 0}" aria-label="${escapeHtml(c.nome)}" title="${escapeHtml(c.nome)}"></button>`).join('')}
            </div>
            <p class="pallini__nome" aria-live="polite">${escapeHtml(primo.nome)}</p>
          </div>
          <div class="prodotto__dettagli">
            <span class="prodotto__prezzo">${euro(principale.prezzo)}</span>
            <span class="prodotto__taglie">${escapeHtml(taglie)}</span>
            <a class="btn btn--fantasma btn--piccolo" href="preordini.html#${principale.id}">Preordina</a>
          </div>
        </div>
      </article>`;
  }).join('');

  // Cambio colore
  contenitore.querySelectorAll('.prodotto').forEach((sezione) => {
    const cat = sezione.dataset.categoria;
    const prodotto = catalogo.prodotti.find((p) => p.categoria === cat);
    const media = sezione.querySelector('.prodotto__media');
    const img = sezione.querySelector('.prodotto__img');
    const nome = sezione.querySelector('.pallini__nome');
    sezione.querySelectorAll('.pallino').forEach((btn) => {
      btn.addEventListener('click', () => {
        const colore = prodotto.colori.find((c) => c.id === btn.dataset.colore);
        sezione.querySelectorAll('.pallino').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
        media.style.setProperty('--sfondo', sfondoPer(colore.hex));
        img.innerHTML = immagineProdotto(prodotto, colore.id);
        img.classList.remove('cambio');
        void img.offsetWidth; // riavvia l'animazione
        img.classList.add('cambio');
        nome.textContent = colore.nome;
      });
    });
  });

  osservaComparse();
  aggiornaScroll();
}

osservaComparse();
caricaVetrina();
