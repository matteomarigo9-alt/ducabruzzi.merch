/* ==========================================================================
   Duca Merch — funzioni condivise tra le pagine
   ========================================================================== */

/** Chiamata alle API del server. In caso di sessione scaduta torna al login. */
export async function api(url, { metodo = 'GET', dati, reindirizzaSe401 = true } = {}) {
  const opzioni = { method: metodo, headers: {}, credentials: 'same-origin' };
  if (dati !== undefined) {
    opzioni.headers['Content-Type'] = 'application/json';
    opzioni.body = JSON.stringify(dati);
  }
  let risposta;
  try {
    risposta = await fetch(url, opzioni);
  } catch {
    throw Object.assign(new Error('Connessione assente. Controlla la rete e riprova.'), { stato: 0 });
  }
  if (risposta.status === 401 && reindirizzaSe401) {
    window.location.href = '/login.html';
    throw Object.assign(new Error('Sessione scaduta.'), { stato: 401 });
  }
  const corpo = await risposta.json().catch(() => ({}));
  if (!risposta.ok) {
    throw Object.assign(new Error(corpo.errore || 'Qualcosa è andato storto.'), { stato: risposta.status, dettagli: corpo });
  }
  return corpo;
}

const formatoEuro = new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', minimumFractionDigits: 0, maximumFractionDigits: 2 });
/** 2500 -> "25 €" */
export const euro = (centesimi) => formatoEuro.format(centesimi / 100);

export const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export const iniziali = (u) => `${(u.nome || '?')[0]}${(u.cognome || '')[0] || ''}`.toUpperCase();

export const riduciMovimento = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* --------------------------------------------------------------------------
   Colori
   -------------------------------------------------------------------------- */
function hexToRgb(hex) {
  const n = parseInt(hex.replace('#', ''), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}
const rgbToHex = (r, g, b) => '#' + [r, g, b].map((v) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0')).join('');

/** Schiarisce (quantita > 0) o scurisce (quantita < 0) un colore. */
export function sfuma(hex, quantita) {
  const [r, g, b] = hexToRgb(hex);
  const t = quantita < 0 ? 0 : 255;
  const p = Math.abs(quantita);
  return rgbToHex(r + (t - r) * p, g + (t - g) * p, b + (t - b) * p);
}
export function mescola(a, b, peso) {
  const [r1, g1, b1] = hexToRgb(a);
  const [r2, g2, b2] = hexToRgb(b);
  return rgbToHex(r1 + (r2 - r1) * peso, g1 + (g2 - g1) * peso, b1 + (b2 - b1) * peso);
}
export function eChiaro(hex) {
  const [r, g, b] = hexToRgb(hex);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 > 0.62;
}
/** Colore pastello dello sfondo dietro al capo. */
export const sfondoPer = (hex) => (eChiaro(hex) ? '#d9d2c1' : mescola(hex, '#f4eee1', 0.8));

/* --------------------------------------------------------------------------
   Illustrazioni dei capi (usate finché non arrivano le foto vere)
   -------------------------------------------------------------------------- */
let contatoreSvg = 0;

function sagoma(forma, c) {
  const { fill, linea, dettaglio, ombra, cordino, logo } = c;
  switch (forma) {
    case 'felpa':
      return `
        <path d="M78 46 C66 48 52 52 44 58 C34 64 30 76 27 92 L15 154 L39 160 L50 106 L50 172 L150 172 L150 106 L161 160 L185 154 L173 92 C170 76 166 64 156 58 C148 52 134 48 122 46 Z"
              fill="${fill}" stroke="${linea}" stroke-width="1.5" stroke-linejoin="round"/>
        <path d="M15 154 L39 160 L38 166 L14 160 Z M161 160 L185 154 L186 160 L162 166 Z" fill="${fill}" stroke="${linea}" stroke-width="1.2"/>
        <path d="M15 154 L39 160 L38 166 L14 160 Z M161 160 L185 154 L186 160 L162 166 Z" fill="${ombra}"/>
        <rect x="50" y="164" width="100" height="10" rx="2" fill="${ombra}"/>
        <path d="M50 106 L50 172 M150 106 L150 172" stroke="${dettaglio}" stroke-width="1.2"/>
        <path d="M44 60 C47 76 49 92 50 106 M156 60 C153 76 151 92 150 106" stroke="${dettaglio}" stroke-width="1.2" fill="none"/>
        <path d="M66 164 L73 132 Q100 127 127 132 L134 164" fill="none" stroke="${dettaglio}" stroke-width="1.6"/>
        <path d="M70 52 C62 30 80 12 100 12 C120 12 138 30 130 52 C120 62 80 62 70 52 Z" fill="${fill}" stroke="${linea}" stroke-width="1.5"/>
        <path d="M82 52 C80 34 90 25 100 25 C110 25 120 34 118 52 C112 60 88 60 82 52 Z" fill="${ombra}" opacity=".9"/>
        <path d="M82 52 C80 34 90 25 100 25 C110 25 120 34 118 52" fill="none" stroke="${dettaglio}" stroke-width="1.2"/>
        <path d="M92 58 L90 94 M108 58 L110 94" stroke="${cordino}" stroke-width="2.4" stroke-linecap="round"/>
        <rect x="88.4" y="92" width="3.4" height="6" rx="1.2" fill="${cordino}"/>
        <rect x="108.2" y="92" width="3.4" height="6" rx="1.2" fill="${cordino}"/>
        ${logo(88, 98, 24)}`;
    case 'tshirt':
      return `
        <path d="M76 34 C86 44 114 44 124 34 L152 42 L184 74 L164 96 L150 84 L150 172 L50 172 L50 84 L36 96 L16 74 L48 42 Z"
              fill="${fill}" stroke="${linea}" stroke-width="1.5" stroke-linejoin="round"/>
        <path d="M76 34 C88 30 112 30 124 34 C114 44 86 44 76 34 Z" fill="${ombra}"/>
        <path d="M76 34 C86 47 114 47 124 34" fill="none" stroke="${dettaglio}" stroke-width="3"/>
        <path d="M20 79 L40 98 M180 79 L160 98" stroke="${dettaglio}" stroke-width="1.4"/>
        <path d="M50 84 L50 172 M150 84 L150 172" stroke="${dettaglio}" stroke-width="1"/>
        <path d="M50 166 L150 166" stroke="${dettaglio}" stroke-width="1.2" stroke-dasharray="3 3"/>
        ${logo(87, 60, 26)}`;
    case 'berretto': {
      let coste = '';
      for (let x = 48; x <= 152; x += 7) coste += `<path d="M${x} 126 L${x} 162" stroke="${dettaglio}" stroke-width="1.4"/>`;
      return `
        <circle cx="100" cy="36" r="17" fill="${fill}" stroke="${linea}" stroke-width="1.5"/>
        <circle cx="100" cy="36" r="17" fill="none" stroke="${dettaglio}" stroke-width="5" stroke-dasharray="1.5 3"/>
        <path d="M46 130 C44 78 70 50 100 50 C130 50 156 78 154 130 Z" fill="${fill}" stroke="${linea}" stroke-width="1.5"/>
        <path d="M100 52 L100 128 M80 56 C70 80 68 104 69 128 M120 56 C130 80 132 104 131 128 M62 70 C54 90 52 110 53 128 M138 70 C146 90 148 110 147 128"
              fill="none" stroke="${dettaglio}" stroke-width="1.2"/>
        <path d="M40 124 Q100 114 160 124 L162 164 Q100 154 38 164 Z" fill="${fill}" stroke="${linea}" stroke-width="1.5"/>
        <path d="M40 124 Q100 114 160 124 L162 164 Q100 154 38 164 Z" fill="${ombra}" opacity=".55"/>
        ${coste}
        <rect x="84" y="125" width="32" height="34" rx="5" fill="${c.patch}" stroke="${linea}" stroke-width="1"/>
        <rect x="86.5" y="127.5" width="27" height="29" rx="3.5" fill="none" stroke="${c.patchLinea}" stroke-width=".8" stroke-dasharray="2 1.6"/>
        ${c.logoSu(89.5, 129.5, 21, c.patchLogo)}`;
    }
    case 'cappello':
      return `
        <path d="M44 128 C44 76 70 50 100 50 C130 50 156 76 156 128 Z" fill="${fill}" stroke="${linea}" stroke-width="1.5"/>
        <path d="M100 52 L100 126 M100 52 C80 68 70 98 70 127 M100 52 C120 68 130 98 130 127"
              fill="none" stroke="${dettaglio}" stroke-width="1.3"/>
        <path d="M100 52 C82 60 56 84 48 120 M100 52 C118 60 144 84 152 120" fill="none" stroke="${dettaglio}" stroke-width="1" stroke-dasharray="2.5 2.5"/>
        <circle cx="76" cy="78" r="2.2" fill="${ombra}"/>
        <circle cx="124" cy="78" r="2.2" fill="${ombra}"/>
        <circle cx="100" cy="50" r="5" fill="${fill}" stroke="${linea}" stroke-width="1.2"/>
        <path d="M44 124 C70 118 130 118 156 124 C170 142 142 168 100 170 C58 168 30 142 44 124 Z"
              fill="${fill}" stroke="${linea}" stroke-width="1.5"/>
        <path d="M44 124 C70 118 130 118 156 124 C170 142 142 168 100 170 C58 168 30 142 44 124 Z" fill="${ombra}" opacity=".6"/>
        <path d="M44 124 C70 118 130 118 156 124 C140 132 60 132 44 124 Z" fill="rgba(0,0,0,.25)"/>
        <path d="M48 134 C60 154 140 154 152 134" fill="none" stroke="${dettaglio}" stroke-width="1.2" stroke-dasharray="3 2.5"/>
        <path d="M44 154 C56 162 144 162 156 154" fill="none" stroke="${dettaglio}" stroke-width="1.2" stroke-dasharray="3 2.5" opacity=".6"/>
        ${logo(87, 74, 26)}`;
    default:
      return '';
  }
}

/** Restituisce il codice SVG del capo (forma: felpa | tshirt | berretto | cappello) nel colore indicato. */
export function svgProdotto(forma, hex) {
  const id = `capo${++contatoreSvg}`;
  const chiaro = eChiaro(hex);
  const colori = {
    fill: `url(#${id}-g)`,
    linea: chiaro ? 'rgba(20,32,26,.28)' : sfuma(hex, -0.45),
    dettaglio: chiaro ? 'rgba(20,32,26,.16)' : 'rgba(0,0,0,.32)',
    ombra: chiaro ? 'rgba(20,32,26,.08)' : 'rgba(0,0,0,.22)',
    cordino: chiaro ? '#cfc8b6' : '#efe9dc',
    patch: '#b88a52',
    patchLinea: '#f2e3c6',
    patchLogo: `${id}-ls`
  };
  // Stemma ricamato: oro sui capi scuri, verde scuro su quelli chiari.
  const logoFiltro = chiaro ? `${id}-lv` : `${id}-lo`;
  const logoSu = (x, y, w, filtro) =>
    `<image href="img/logo.png" x="${x}" y="${y}" width="${w}" height="${(w * 1.37).toFixed(1)}" filter="url(#${filtro})" preserveAspectRatio="xMidYMid meet"/>`;
  colori.logo = (x, y, w) => logoSu(x, y, w, logoFiltro);
  colori.logoSu = logoSu;

  const matrice = (r, g, b, a = 1) => `0 0 0 0 ${r} 0 0 0 0 ${g} 0 0 0 0 ${b} 0 0 0 ${a} 0`;
  return `
    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" role="img" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="${id}-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stop-color="${sfuma(hex, chiaro ? 0.4 : 0.16)}"/>
          <stop offset=".55" stop-color="${hex}"/>
          <stop offset="1" stop-color="${sfuma(hex, chiaro ? -0.1 : -0.3)}"/>
        </linearGradient>
        <filter id="${id}-lo" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${matrice(0.91, 0.80, 0.53, 0.95)}"/></filter>
        <filter id="${id}-lv" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${matrice(0.07, 0.18, 0.13, 0.9)}"/></filter>
        <filter id="${id}-ls" color-interpolation-filters="sRGB"><feColorMatrix type="matrix" values="${matrice(0.98, 0.93, 0.82, 0.95)}"/></filter>
      </defs>
      ${sagoma(forma, colori)}
    </svg>`;
}

/** HTML dell'immagine del prodotto: foto se disponibile, altrimenti illustrazione. */
export function immagineProdotto(prodotto, coloreId) {
  const colore = prodotto.colori.find((c) => c.id === coloreId) || prodotto.colori[0];
  const foto = (prodotto.immagini && prodotto.immagini[colore.id]) || prodotto.immagine;
  const alt = `${prodotto.nome}${prodotto.variante ? ' ' + prodotto.variante : ''} – ${colore.nome}`;
  if (foto) return `<img src="${escapeHtml(foto)}" alt="${escapeHtml(alt)}" loading="lazy">`;
  return svgProdotto(prodotto.forma, colore.hex).replace('aria-hidden="true"', `aria-label="${escapeHtml(alt)}"`);
}

/* --------------------------------------------------------------------------
   Cielo stellato animato (richiama le stelle dello stemma)
   -------------------------------------------------------------------------- */
export function avviaCielo(canvas, { densita = 1 } = {}) {
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let stelle = [];
  let larghezza = 0;
  let altezza = 0;
  let animazione = 0;
  let visibile = true;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);

  function crea() {
    const r = canvas.getBoundingClientRect();
    larghezza = r.width;
    altezza = r.height;
    canvas.width = larghezza * dpr;
    canvas.height = altezza * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const n = Math.round((larghezza * altezza) / 9000 * densita);
    stelle = Array.from({ length: n }, () => ({
      x: Math.random() * larghezza,
      y: Math.random() * altezza,
      r: Math.random() < 0.08 ? 3 + Math.random() * 3 : 0.6 + Math.random() * 1.2,
      fase: Math.random() * Math.PI * 2,
      vel: 0.4 + Math.random() * 1.2,
      deriva: (Math.random() - 0.5) * 0.06
    }));
  }

  function stellaSeiPunte(x, y, r) {
    ctx.beginPath();
    for (let i = 0; i < 12; i++) {
      const ang = (Math.PI / 6) * i - Math.PI / 2;
      const rr = i % 2 === 0 ? r : r * 0.42;
      ctx.lineTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr);
    }
    ctx.closePath();
    ctx.fill();
  }

  function disegna(t) {
    ctx.clearRect(0, 0, larghezza, altezza);
    for (const s of stelle) {
      const luce = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t / 1000 * s.vel + s.fase));
      s.x += s.deriva;
      if (s.x < -5) s.x = larghezza + 5;
      if (s.x > larghezza + 5) s.x = -5;
      if (s.r > 2.5) {
        ctx.fillStyle = `rgba(231, 205, 136, ${luce * 0.8})`;
        stellaSeiPunte(s.x, s.y, s.r * (0.85 + luce * 0.25));
      } else {
        ctx.fillStyle = `rgba(244, 238, 225, ${luce * 0.75})`;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  function ciclo(t) {
    if (visibile) disegna(t);
    animazione = requestAnimationFrame(ciclo);
  }

  crea();
  if (riduciMovimento()) {
    disegna(0);
  } else {
    animazione = requestAnimationFrame(ciclo);
    new IntersectionObserver(([e]) => { visibile = e.isIntersecting; }).observe(canvas);
  }
  let timer;
  window.addEventListener('resize', () => {
    clearTimeout(timer);
    timer = setTimeout(() => { crea(); if (riduciMovimento()) disegna(0); }, 150);
  });
  return () => cancelAnimationFrame(animazione);
}

/* --------------------------------------------------------------------------
   Rivelazione degli elementi allo scroll
   -------------------------------------------------------------------------- */
export function osservaComparse(radice = document) {
  const elementi = radice.querySelectorAll('[data-reveal]:not(.visibile), .prodotto:not(.visibile)');
  if (!('IntersectionObserver' in window)) {
    elementi.forEach((el) => el.classList.add('visibile'));
    return;
  }
  const osservatore = new IntersectionObserver((voci) => {
    for (const v of voci) {
      if (v.isIntersecting) {
        v.target.classList.add('visibile');
        osservatore.unobserve(v.target);
      }
    }
  }, { threshold: 0.18, rootMargin: '0px 0px -8% 0px' });
  elementi.forEach((el) => osservatore.observe(el));
}

/* --------------------------------------------------------------------------
   Testata con utente collegato
   -------------------------------------------------------------------------- */
export async function avviaTestata({ sempreSolida = false } = {}) {
  const testata = document.querySelector('.testata');
  const aggiorna = () => testata.classList.toggle('testata--solida', sempreSolida || window.scrollY > 40);
  aggiorna();
  window.addEventListener('scroll', aggiorna, { passive: true });

  const utente = await api('/api/me');
  const box = testata.querySelector('[data-utente]');
  if (box) {
    box.innerHTML = `
      <span class="utente__avatar" aria-hidden="true">${escapeHtml(iniziali(utente))}</span>
      <span class="utente__info"><strong>${escapeHtml(utente.nome)}</strong><small>Classe ${escapeHtml(utente.classe)}</small></span>
      <button class="utente__esci" type="button">Esci</button>`;
    box.hidden = false;
    box.querySelector('.utente__esci').addEventListener('click', async () => {
      try { await api('/api/logout', { metodo: 'POST', dati: {}, reindirizzaSe401: false }); } catch { /* si esce comunque */ }
      window.location.href = '/login.html';
    });
  }
  return utente;
}

/* --------------------------------------------------------------------------
   Notifica temporanea
   -------------------------------------------------------------------------- */
let timerToast;
export function toast(messaggio, { errore = false } = {}) {
  let el = document.querySelector('.toast');
  if (!el) {
    el = document.createElement('div');
    el.className = 'toast';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    document.body.appendChild(el);
  }
  el.textContent = messaggio;
  el.classList.toggle('toast--errore', errore);
  el.classList.add('visibile');
  clearTimeout(timerToast);
  timerToast = setTimeout(() => el.classList.remove('visibile'), 2800);
}
