# Duca Merch

Sito del merchandising ufficiale dell'**Istituto Duca degli Abruzzi** di Padova.

- **login.html**: accesso con nome, cognome, classe e mail istituzionale (`@ducabruzzi.eu`)
- **index.html**: vetrina della collezione con effetti allo scroll e pulsante **PREORDINA ORA**
- **preordini.html**: preordine di felpe (uomo, donna, unisex), t-shirt, berretti e cappelli con colore, taglia (XS–3XL) e quantità; storico dei propri preordini con possibilità di annullarli
- **admin.html**: area riservata con il riepilogo "Risposte" (grafici colore × taglia per ogni articolo, come nel modulo originale), elenco dei preordini, esportazione completa (CSV) e **riepilogo per il fornitore** in Excel (.xlsx: solo quantità per articolo, colore e taglia, senza dati degli studenti)

## Requisiti

- [Node.js](https://nodejs.org) **22.13 o superiore** (consigliato: l'ultima LTS). Il database è SQLite, già integrato in Node: non serve installare MySQL o altro.

## Avvio

```bash
npm install
```

```bash
npm start
```

Poi apri <http://localhost:3000>.

Durante lo sviluppo puoi usare `npm run dev`: il server si riavvia da solo quando modifichi i file del back-end.

## Configurazione (`.env`)

Copia `.env.example` in `.env` e modifica i valori:

| Variabile | A cosa serve |
|---|---|
| `PORT` | Porta del sito (default 3000) |
| `DOMINIO_EMAIL` | Dominio mail ammesso al login (default `ducabruzzi.eu`) |
| `ADMIN_PASSWORD` | Password di `/admin.html`. Se vuota, l'area admin è disattivata |
| `PREORDINI_APERTI` | `false` per chiudere i preordini lasciando il sito visibile |
| `COOKIE_SECURE` | `true` in produzione con HTTPS |
| `TRUST_PROXY` | `true` se il sito è dietro un reverse proxy (nginx, Render, Railway…) |

## Struttura

```
server/
  server.js     API, sessioni, controllo accessi, pagine
  db.js         database SQLite (creato in data/merch.db)
  prodotti.js   CATALOGO: prodotti, prezzi, taglie, colori  ← si modifica qui
public/
  index.html  preordini.html  login.html  admin.html
  css/style.css
  js/common.js  index.js  preordini.js  login.js  admin.js
  img/logo.png  (stemma con sfondo trasparente)
  img/prodotti/ (qui vanno le foto dei prodotti)
```

## Aggiungere le foto dei prodotti

Finché non ci sono foto, il sito disegna un'illustrazione di ogni capo nel colore scelto, con lo stemma ricamato.

1. Copia le foto in `public/img/prodotti/` (meglio `.jpg` o `.webp` a sfondo neutro, circa 1200 px).
2. In `server/prodotti.js`, per il prodotto giusto imposta:
   ```js
   immagine: 'img/prodotti/felpa-uomo.jpg',            // foto generica
   immagini: { nero: 'img/prodotti/felpa-uomo-nero.jpg', // (facoltativo) una foto per colore
               bianco: 'img/prodotti/felpa-uomo-bianco.jpg' }
   ```
3. Riavvia il server.

Dallo stesso file si cambiano prezzi, colori disponibili e taglie.

## Sicurezza: cosa c'è e cosa manca

Già presenti: sessioni con cookie `httpOnly`, token salvati solo come hash, prezzi calcolati dal server (il browser non può modificarli), validazione di prodotto/colore/taglia/quantità, limite ai tentativi di login, password admin confrontata in tempo costante, intestazioni di sicurezza (CSP, ecc.), protezione dell'export CSV dalle formule Excel.

Da sapere: come richiesto, l'accesso chiede solo i dati e la mail istituzionale, **senza verificare che la mail appartenga davvero a chi la scrive**. Chi conosce l'indirizzo di un compagno potrebbe entrare a suo nome. Se serve, il passo successivo è l'invio di un codice di verifica alla mail (serve un account SMTP della scuola).

## Messa online

Funziona su qualsiasi servizio che esegue Node.js (VPS della scuola, Render, Railway, Fly.io…). Ricordati di:

- impostare `ADMIN_PASSWORD`, `COOKIE_SECURE=true` e, se serve, `TRUST_PROXY=true`
- usare HTTPS
- conservare la cartella `data/` (contiene il database) e farne un backup periodico
