'use strict';

/*
 * Duca Merch — server
 * Avvio:  npm install   (solo la prima volta)
 *         npm start     -> http://localhost:3000
 */

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const ROOT = path.join(__dirname, '..');
const FILE_ENV = path.join(ROOT, '.env');
if (fs.existsSync(FILE_ENV)) process.loadEnvFile(FILE_ENV);

const express = require('express');
const ExcelJS = require('exceljs');
const { db, transazione } = require('./db');
const { COLORI, PRODOTTI, trovaProdotto, catalogoPubblico } = require('./prodotti');

// ---------------------------------------------------------------------------
// Configurazione
// ---------------------------------------------------------------------------
const PORT = Number(process.env.PORT) || 3000;
const DOMINIO_EMAIL = (process.env.DOMINIO_EMAIL || 'ducabruzzi.eu').toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const COOKIE_SECURE = process.env.COOKIE_SECURE === 'true';
const PREORDINI_APERTI = process.env.PREORDINI_APERTI !== 'false';

const COOKIE_UTENTE = 'duca_sessione';
const COOKIE_ADMIN = 'duca_admin';
const DURATA_SESSIONE_MS = 7 * 24 * 60 * 60 * 1000; // 7 giorni
const DURATA_ADMIN_MS = 8 * 60 * 60 * 1000;         // 8 ore
const MAX_QUANTITA_RIGA = 20;
const MAX_RIGHE_ORDINE = 60;
const PUBLIC_DIR = path.join(ROOT, 'public');

const app = express();
app.disable('x-powered-by');
if (process.env.TRUST_PROXY === 'true') app.set('trust proxy', 1);

// ---------------------------------------------------------------------------
// Utilità
// ---------------------------------------------------------------------------
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const adesso = () => new Date().toISOString();
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const REGEX_EMAIL = new RegExp(`^[a-z0-9](?:[a-z0-9._%+-]{0,62}[a-z0-9])?@${escapeRegex(DOMINIO_EMAIL)}$`);

function leggiCookie(req) {
  const out = {};
  const header = req.headers.cookie;
  if (!header) return out;
  for (const parte of header.split(';')) {
    const i = parte.indexOf('=');
    if (i < 0) continue;
    const k = parte.slice(0, i).trim();
    const v = parte.slice(i + 1).trim();
    try { out[k] = decodeURIComponent(v); } catch { out[k] = v; }
  }
  return out;
}

function opzioniCookie(maxAge) {
  return { httpOnly: true, sameSite: 'lax', secure: COOKIE_SECURE, maxAge, path: '/' };
}

/** "  mARIO  rossi " -> "Mario Rossi". Restituisce '' se non valido. */
function pulisciNome(valore) {
  const s = String(valore ?? '').trim().replace(/\s+/g, ' ');
  if (!/^[\p{L}][\p{L}' .-]{0,49}$/u.test(s)) return '';
  return s.toLowerCase().replace(/(^|[\s'-])(\p{L})/gu, (_, a, b) => a + b.toUpperCase());
}

/** " 3^ b " -> "3B". Restituisce '' se non valido. */
function normalizzaClasse(valore) {
  const s = String(valore ?? '').toUpperCase().replace(/[\s^°ª.\-]/g, '');
  return /^[1-5][A-Z]{1,5}$/.test(s) ? s : '';
}

/** Limita i tentativi per indirizzo IP (in memoria). */
function limitatore(max, finestraMs, messaggio) {
  const mappa = new Map();
  setInterval(() => {
    const ora = Date.now();
    for (const [k, v] of mappa) if (v.reset < ora) mappa.delete(k);
  }, finestraMs).unref();
  return (req, res, next) => {
    const ora = Date.now();
    let voce = mappa.get(req.ip);
    if (!voce || voce.reset < ora) {
      voce = { n: 0, reset: ora + finestraMs };
      mappa.set(req.ip, voce);
    }
    voce.n += 1;
    if (voce.n > max) return res.status(429).json({ errore: messaggio });
    next();
  };
}

// ---------------------------------------------------------------------------
// Sessioni
// ---------------------------------------------------------------------------
const stmt = {
  inserisciSessione: db.prepare('INSERT INTO sessioni (token_hash, utente_id, scade_il) VALUES (?, ?, ?)'),
  utenteDaSessione: db.prepare(`
    SELECT u.id, u.nome, u.cognome, u.classe, u.email
    FROM sessioni s JOIN utenti u ON u.id = s.utente_id
    WHERE s.token_hash = ? AND s.scade_il > ?`),
  eliminaSessione: db.prepare('DELETE FROM sessioni WHERE token_hash = ?'),
  pulisciSessioni: db.prepare('DELETE FROM sessioni WHERE scade_il <= ?')
};

function creaSessione(utenteId) {
  const token = crypto.randomBytes(32).toString('hex');
  stmt.inserisciSessione.run(sha256(token), utenteId, Date.now() + DURATA_SESSIONE_MS);
  return token;
}

const sessioniAdmin = new Map(); // hash token -> scadenza

function adminValido(req) {
  const token = leggiCookie(req)[COOKIE_ADMIN];
  if (!token) return false;
  const scadenza = sessioniAdmin.get(sha256(token));
  return Boolean(scadenza && scadenza > Date.now());
}

setInterval(() => {
  const ora = Date.now();
  stmt.pulisciSessioni.run(ora);
  for (const [k, v] of sessioniAdmin) if (v <= ora) sessioniAdmin.delete(k);
}, 60 * 60 * 1000).unref();
stmt.pulisciSessioni.run(Date.now());

// ---------------------------------------------------------------------------
// Middleware globali
// ---------------------------------------------------------------------------
app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Content-Security-Policy': [
      "default-src 'self'",
      "script-src 'self'",
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com",
      "img-src 'self' data: https:",
      "connect-src 'self'",
      "frame-ancestors 'none'",
      "base-uri 'self'",
      "form-action 'self'"
    ].join('; ')
  });
  next();
});

app.use(express.json({ limit: '50kb' }));

// Riconosce l'utente collegato (se c'è) su ogni richiesta.
app.use((req, _res, next) => {
  const token = leggiCookie(req)[COOKIE_UTENTE];
  req.utente = token ? stmt.utenteDaSessione.get(sha256(token), Date.now()) || null : null;
  next();
});

// Le richieste che modificano dati devono essere JSON (protezione base anti-CSRF).
app.use('/api', (req, res, next) => {
  if (req.method === 'POST' && !req.is('application/json')) {
    return res.status(415).json({ errore: 'Formato della richiesta non valido.' });
  }
  next();
});

function richiediUtente(req, res, next) {
  if (!req.utente) return res.status(401).json({ errore: 'Sessione scaduta: accedi di nuovo.' });
  next();
}

function richiediAdmin(req, res, next) {
  if (!adminValido(req)) return res.status(401).json({ errore: 'Accesso amministratore richiesto.' });
  next();
}

// ---------------------------------------------------------------------------
// API — accesso studenti
// ---------------------------------------------------------------------------
app.post('/api/login',
  limitatore(20, 10 * 60 * 1000, 'Troppi tentativi di accesso. Riprova tra qualche minuto.'),
  (req, res) => {
    const b = req.body || {};
    const nome = pulisciNome(b.nome);
    const cognome = pulisciNome(b.cognome);
    const classe = normalizzaClasse(b.classe);
    const email = String(b.email ?? '').trim().toLowerCase();

    const errori = {};
    if (!nome) errori.nome = 'Inserisci un nome valido.';
    if (!cognome) errori.cognome = 'Inserisci un cognome valido.';
    if (!classe) errori.classe = 'Scrivi la classe come numero + sezione, es. 3B.';
    if (!REGEX_EMAIL.test(email)) errori.email = `Usa la tua mail istituzionale @${DOMINIO_EMAIL}.`;
    if (Object.keys(errori).length) {
      return res.status(400).json({ errore: 'Controlla i campi evidenziati.', errori });
    }

    const ora = adesso();
    db.prepare(`
      INSERT INTO utenti (nome, cognome, classe, email, creato_il, ultimo_accesso)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(email) DO UPDATE SET
        nome = excluded.nome, cognome = excluded.cognome,
        classe = excluded.classe, ultimo_accesso = excluded.ultimo_accesso
    `).run(nome, cognome, classe, email, ora, ora);

    const { id } = db.prepare('SELECT id FROM utenti WHERE email = ?').get(email);
    res.cookie(COOKIE_UTENTE, creaSessione(id), opzioniCookie(DURATA_SESSIONE_MS));
    res.json({ ok: true, utente: { nome, cognome, classe, email } });
  });

app.post('/api/logout', (req, res) => {
  const token = leggiCookie(req)[COOKIE_UTENTE];
  if (token) stmt.eliminaSessione.run(sha256(token));
  res.clearCookie(COOKIE_UTENTE, { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', richiediUtente, (req, res) => {
  const { nome, cognome, classe, email } = req.utente;
  res.json({ nome, cognome, classe, email, preordiniAperti: PREORDINI_APERTI });
});

app.get('/api/prodotti', richiediUtente, (_req, res) => {
  res.json(catalogoPubblico());
});

// ---------------------------------------------------------------------------
// API — preordini
// ---------------------------------------------------------------------------
app.post('/api/ordini', richiediUtente, (req, res) => {
  if (!PREORDINI_APERTI) {
    return res.status(403).json({ errore: 'I preordini al momento sono chiusi.' });
  }
  const b = req.body || {};
  const righeIn = Array.isArray(b.righe) ? b.righe : [];
  const note = String(b.note ?? '').trim().slice(0, 500);

  if (!righeIn.length) return res.status(400).json({ errore: 'Il preordine è vuoto.' });
  if (righeIn.length > MAX_RIGHE_ORDINE) return res.status(400).json({ errore: 'Troppi articoli in un solo preordine.' });

  const righe = [];
  const perChiave = new Map();
  for (const r of righeIn) {
    const prodotto = trovaProdotto(r?.prodottoId);
    if (!prodotto) return res.status(400).json({ errore: 'Uno degli articoli non esiste più nel catalogo.' });
    if (!prodotto.colori.includes(r.colore)) return res.status(400).json({ errore: `Colore non disponibile per ${prodotto.nome}.` });
    if (!prodotto.taglie.includes(r.taglia)) return res.status(400).json({ errore: `Taglia non disponibile per ${prodotto.nome}.` });
    const quantita = Number(r.quantita);
    if (!Number.isInteger(quantita) || quantita < 1 || quantita > MAX_QUANTITA_RIGA) {
      return res.status(400).json({ errore: `La quantità deve essere tra 1 e ${MAX_QUANTITA_RIGA}.` });
    }
    const chiave = `${prodotto.id}|${r.colore}|${r.taglia}`;
    const esistente = perChiave.get(chiave);
    if (esistente) {
      esistente.quantita += quantita;
      if (esistente.quantita > MAX_QUANTITA_RIGA) {
        return res.status(400).json({ errore: `Massimo ${MAX_QUANTITA_RIGA} pezzi per stesso articolo, colore e taglia.` });
      }
    } else {
      const riga = { prodotto, colore: r.colore, taglia: r.taglia, quantita };
      perChiave.set(chiave, riga);
      righe.push(riga);
    }
  }

  const totale = righe.reduce((s, r) => s + r.quantita * r.prodotto.prezzo, 0);
  const creatoIl = adesso();

  const id = transazione(() => {
    const { lastInsertRowid } = db
      .prepare('INSERT INTO ordini (utente_id, totale, note, creato_il) VALUES (?, ?, ?, ?)')
      .run(req.utente.id, totale, note, creatoIl);
    const inserisci = db.prepare(`
      INSERT INTO righe_ordine (ordine_id, prodotto_id, prodotto_nome, colore_id, colore_nome, taglia, quantita, prezzo_unitario)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    for (const r of righe) {
      const nomeCompleto = r.prodotto.variante ? `${r.prodotto.nome} – ${r.prodotto.variante}` : r.prodotto.nome;
      inserisci.run(lastInsertRowid, r.prodotto.id, nomeCompleto, r.colore, COLORI[r.colore].nome,
        r.taglia, r.quantita, r.prodotto.prezzo);
    }
    return Number(lastInsertRowid);
  });

  res.status(201).json({ ok: true, ordine: { id, totale, creatoIl } });
});

function righeDi(ordineId) {
  return db.prepare(`
    SELECT prodotto_id AS prodottoId, prodotto_nome AS prodotto, colore_id AS coloreId,
           colore_nome AS colore, taglia, quantita, prezzo_unitario AS prezzo
    FROM righe_ordine WHERE ordine_id = ? ORDER BY id`).all(ordineId);
}

app.get('/api/ordini/miei', richiediUtente, (req, res) => {
  const ordini = db.prepare(`
    SELECT id, totale, note, stato, creato_il AS creatoIl
    FROM ordini WHERE utente_id = ? ORDER BY id DESC`).all(req.utente.id);
  res.json(ordini.map((o) => ({ ...o, righe: righeDi(o.id) })));
});

app.delete('/api/ordini/:id', richiediUtente, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ errore: 'Preordine non valido.' });
  const { changes } = db.prepare(`
    UPDATE ordini SET stato = 'annullato'
    WHERE id = ? AND utente_id = ? AND stato = 'ricevuto'`).run(id, req.utente.id);
  if (!changes) return res.status(404).json({ errore: 'Preordine non trovato o già annullato.' });
  res.json({ ok: true });
});

// ---------------------------------------------------------------------------
// API — amministrazione (riepilogo come nella vista "Risposte" del modulo)
// ---------------------------------------------------------------------------
app.post('/api/admin/login',
  limitatore(5, 10 * 60 * 1000, 'Troppi tentativi. Riprova tra 10 minuti.'),
  (req, res) => {
    if (!ADMIN_PASSWORD) {
      return res.status(503).json({ errore: 'Area admin disattivata: imposta ADMIN_PASSWORD nel file .env e riavvia il server.' });
    }
    const inserita = Buffer.from(sha256(req.body?.password ?? ''));
    const attesa = Buffer.from(sha256(ADMIN_PASSWORD));
    if (!crypto.timingSafeEqual(inserita, attesa)) {
      return res.status(401).json({ errore: 'Password errata.' });
    }
    const token = crypto.randomBytes(32).toString('hex');
    sessioniAdmin.set(sha256(token), Date.now() + DURATA_ADMIN_MS);
    res.cookie(COOKIE_ADMIN, token, opzioniCookie(DURATA_ADMIN_MS));
    res.json({ ok: true });
  });

app.post('/api/admin/logout', (req, res) => {
  const token = leggiCookie(req)[COOKIE_ADMIN];
  if (token) sessioniAdmin.delete(sha256(token));
  res.clearCookie(COOKIE_ADMIN, { path: '/' });
  res.json({ ok: true });
});

app.get('/api/admin/stato', (req, res) => res.json({ admin: adminValido(req) }));

/** Quantità dei preordini attivi raggruppate per articolo → colore → taglia. */
function quantitaPerProdotto() {
  const quantita = db.prepare(`
    SELECT r.prodotto_id AS prodottoId, r.colore_id AS coloreId, r.taglia, SUM(r.quantita) AS q
    FROM righe_ordine r JOIN ordini o ON o.id = r.ordine_id
    WHERE o.stato = 'ricevuto'
    GROUP BY r.prodotto_id, r.colore_id, r.taglia`).all();

  const { prodotti } = catalogoPubblico();
  return prodotti.map((p) => {
    const matrice = {};
    let totalePezzi = 0;
    for (const r of quantita.filter((x) => x.prodottoId === p.id)) {
      matrice[r.coloreId] ??= {};
      matrice[r.coloreId][r.taglia] = r.q;
      totalePezzi += r.q;
    }
    return { id: p.id, nome: p.nome, variante: p.variante, prezzo: p.prezzo, taglie: p.taglie, colori: p.colori, matrice, totalePezzi };
  });
}

app.get('/api/admin/riepilogo', richiediAdmin, (_req, res) => {
  const perProdotto = quantitaPerProdotto();
  const kpi = db.prepare(`
    SELECT COUNT(*) AS ordini, COALESCE(SUM(totale), 0) AS incasso, COUNT(DISTINCT utente_id) AS studenti
    FROM ordini WHERE stato = 'ricevuto'`).get();
  kpi.pezzi = perProdotto.reduce((s, p) => s + p.totalePezzi, 0);

  const ordini = db.prepare(`
    SELECT o.id, o.totale, o.note, o.stato, o.creato_il AS creatoIl,
           u.nome, u.cognome, u.classe, u.email
    FROM ordini o JOIN utenti u ON u.id = o.utente_id
    ORDER BY o.id DESC`).all().map((o) => ({ ...o, righe: righeDi(o.id) }));

  res.json({ kpi, prodotti: perProdotto, ordini });
});

// File Excel da mandare al fornitore: quanti pezzi servono per articolo, colore e taglia.
// Contiene solo i preordini attivi e nessun dato degli studenti.
app.get('/api/admin/riepilogo-fornitore.xlsx', richiediAdmin, async (_req, res, next) => {
  try {
    const prodotti = quantitaPerProdotto().filter((p) => p.totalePezzi > 0);
    const oggi = new Date();
    const dataLeggibile = oggi.toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Europe/Rome' });

    const wb = new ExcelJS.Workbook();
    wb.creator = 'Duca Merch';
    wb.created = oggi;

    const VERDE = 'FF112E21';
    const CREMA = 'FFF4EEE1';
    const ORO = 'FFC9A24B';
    const bordo = { style: 'thin', color: { argb: 'FFBFB8A6' } };
    const bordi = { top: bordo, left: bordo, bottom: bordo, right: bordo };
    const maxColonne = Math.max(2, ...prodotti.map((p) => p.taglie.length + 2));

    // --- Foglio 1: dettaglio per articolo / colore / taglia ---
    const ws = wb.addWorksheet('Riepilogo fornitore', {
      pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9 },
      views: [{ showGridLines: false }]
    });
    ws.getColumn(1).width = 24;
    for (let c = 2; c <= maxColonne; c++) ws.getColumn(c).width = 11;

    const titolo = ws.addRow(['Istituto Duca degli Abruzzi – Riepilogo ordine merch']);
    titolo.font = { bold: true, size: 16, color: { argb: VERDE } };
    titolo.height = 26;
    ws.mergeCells(titolo.number, 1, titolo.number, maxColonne);
    const sotto = ws.addRow([`Aggiornato al ${dataLeggibile} · quantità totali dei preordini confermati`]);
    sotto.font = { italic: true, color: { argb: 'FF5D6A62' } };
    ws.mergeCells(sotto.number, 1, sotto.number, maxColonne);
    ws.addRow([]);

    if (!prodotti.length) {
      ws.addRow(['Nessun preordine attivo.']).font = { italic: true };
    }

    let totaleGenerale = 0;
    for (const p of prodotti) {
      const ultimaCol = p.taglie.length + 2;
      const nome = p.variante ? `${p.nome} – ${p.variante}` : p.nome;

      const rTitolo = ws.addRow([nome.toUpperCase()]);
      ws.mergeCells(rTitolo.number, 1, rTitolo.number, ultimaCol);
      rTitolo.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: VERDE } };
      rTitolo.getCell(1).font = { bold: true, size: 12, color: { argb: 'FFFFFFFF' } };
      rTitolo.height = 22;
      rTitolo.getCell(1).alignment = { vertical: 'middle', indent: 1 };

      const rTest = ws.addRow(['Colore', ...p.taglie, 'Totale']);
      rTest.eachCell((cella, n) => {
        cella.font = { bold: true, color: { argb: VERDE } };
        cella.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: CREMA } };
        cella.alignment = { horizontal: n === 1 ? 'left' : 'center' };
        cella.border = bordi;
      });

      for (const c of p.colori) {
        const valori = p.taglie.map((t) => p.matrice[c.id]?.[t] || 0);
        const tot = valori.reduce((a, b) => a + b, 0);
        if (!tot) continue; // al fornitore servono solo i colori effettivamente ordinati
        const r = ws.addRow([c.nome, ...valori.map((v) => v || null), tot]);
        r.eachCell({ includeEmpty: true }, (cella, n) => {
          if (n > ultimaCol) return;
          cella.border = bordi;
          if (n > 1) cella.alignment = { horizontal: 'center' };
        });
        r.getCell(ultimaCol).font = { bold: true };
      }

      const totTaglie = p.taglie.map((t) => p.colori.reduce((s, c) => s + (p.matrice[c.id]?.[t] || 0), 0));
      const rTot = ws.addRow(['Totale', ...totTaglie.map((v) => v || null), p.totalePezzi]);
      rTot.eachCell({ includeEmpty: true }, (cella, n) => {
        if (n > ultimaCol) return;
        cella.font = { bold: true };
        cella.border = { ...bordi, top: { style: 'medium', color: { argb: VERDE } } };
        if (n > 1) cella.alignment = { horizontal: 'center' };
      });
      totaleGenerale += p.totalePezzi;
      ws.addRow([]);
    }

    if (prodotti.length) {
      const rFin = ws.addRow(['TOTALE PEZZI DA ORDINARE', ...Array(maxColonne - 2).fill(null), totaleGenerale]);
      rFin.eachCell({ includeEmpty: true }, (cella, n) => {
        if (n > maxColonne) return;
        cella.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: ORO } };
        cella.font = { bold: true, size: 12, color: { argb: VERDE } };
      });
      rFin.getCell(maxColonne).alignment = { horizontal: 'center' };
      rFin.height = 22;
    }

    // --- Foglio 2: totale pezzi per articolo ---
    const ws2 = wb.addWorksheet('Totali per articolo', { views: [{ showGridLines: false }] });
    ws2.columns = [{ header: 'Articolo', key: 'a', width: 42 }, { header: 'Pezzi', key: 'q', width: 12 }];
    ws2.getRow(1).eachCell((cella) => {
      cella.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cella.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: VERDE } };
      cella.border = bordi;
    });
    for (const p of prodotti) {
      const r = ws2.addRow({ a: p.variante ? `${p.nome} – ${p.variante}` : p.nome, q: p.totalePezzi });
      r.eachCell((cella) => { cella.border = bordi; });
      r.getCell(2).alignment = { horizontal: 'center' };
    }
    const r2 = ws2.addRow({ a: 'TOTALE', q: totaleGenerale });
    r2.font = { bold: true };
    r2.eachCell((cella) => {
      cella.border = bordi;
      cella.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: ORO } };
    });
    r2.getCell(2).alignment = { horizontal: 'center' };

    const buffer = await wb.xlsx.writeBuffer();
    res.set({
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="riepilogo-fornitore-${oggi.toISOString().slice(0, 10)}.xlsx"`
    });
    res.send(Buffer.from(buffer));
  } catch (err) {
    next(err);
  }
});

// Cambia lo stato di un preordine: { stato: 'annullato' | 'ricevuto' } (annulla o ripristina)
app.post('/api/admin/ordini/:id/stato', richiediAdmin, (req, res) => {
  const id = Number(req.params.id);
  const stato = req.body?.stato;
  if (!Number.isInteger(id) || !['annullato', 'ricevuto'].includes(stato)) {
    return res.status(400).json({ errore: 'Richiesta non valida.' });
  }
  const { changes } = db.prepare('UPDATE ordini SET stato = ? WHERE id = ?').run(stato, id);
  if (!changes) return res.status(404).json({ errore: 'Preordine non trovato.' });
  res.json({ ok: true });
});

// Eliminazione definitiva (le righe vengono cancellate in cascata)
app.delete('/api/admin/ordini/:id', richiediAdmin, (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id)) return res.status(400).json({ errore: 'Preordine non valido.' });
  const { changes } = transazione(() => {
    db.prepare('DELETE FROM righe_ordine WHERE ordine_id = ?').run(id);
    return db.prepare('DELETE FROM ordini WHERE id = ?').run(id);
  });
  if (!changes) return res.status(404).json({ errore: 'Preordine non trovato.' });
  res.json({ ok: true });
});

app.get('/api/admin/export.csv', richiediAdmin, (_req, res) => {
  const righe = db.prepare(`
    SELECT o.id, o.creato_il, o.stato, u.cognome, u.nome, u.classe, u.email,
           r.prodotto_nome, r.colore_nome, r.taglia, r.quantita, r.prezzo_unitario, o.note
    FROM righe_ordine r
    JOIN ordini o ON o.id = r.ordine_id
    JOIN utenti u ON u.id = o.utente_id
    ORDER BY o.id, r.id`).all();

  const cella = (v) => {
    let s = String(v ?? '');
    if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; // evita formule malevole in Excel
    return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const euro = (c) => (c / 100).toFixed(2).replace('.', ',');
  const intestazione = ['Preordine', 'Data', 'Stato', 'Cognome', 'Nome', 'Classe', 'Email',
    'Articolo', 'Colore', 'Taglia', 'Quantità', 'Prezzo unitario (€)', 'Subtotale (€)', 'Note'];
  const linee = righe.map((r) => [
    r.id, new Date(r.creato_il).toLocaleString('it-IT', { timeZone: 'Europe/Rome' }), r.stato,
    r.cognome, r.nome, r.classe, r.email, r.prodotto_nome, r.colore_nome, r.taglia, r.quantita,
    euro(r.prezzo_unitario), euro(r.prezzo_unitario * r.quantita), r.note
  ].map(cella).join(';'));

  const nomeFile = `preordini-duca-${new Date().toISOString().slice(0, 10)}.csv`;
  res.set({
    'Content-Type': 'text/csv; charset=utf-8',
    'Content-Disposition': `attachment; filename="${nomeFile}"`
  });
  res.send('﻿' + [intestazione.join(';'), ...linee].join('\r\n'));
});

app.use('/api', (_req, res) => res.status(404).json({ errore: 'Risorsa non trovata.' }));

// ---------------------------------------------------------------------------
// Pagine HTML (con controllo di accesso) e file statici
// ---------------------------------------------------------------------------
const PAGINE = {
  '/': { file: 'index.html', protetta: true },
  '/index.html': { file: 'index.html', protetta: true },
  '/preordini.html': { file: 'preordini.html', protetta: true },
  '/login.html': { file: 'login.html', protetta: false, soloOspiti: true },
  '/admin.html': { file: 'admin.html', protetta: false }
};

app.use((req, res, next) => {
  if (req.method !== 'GET' && req.method !== 'HEAD') return next();
  const percorso = req.path.toLowerCase();
  const pagina = PAGINE[percorso];
  if (pagina) {
    if (pagina.protetta && !req.utente) return res.redirect('/login.html');
    if (pagina.soloOspiti && req.utente) return res.redirect('/');
    res.set('Cache-Control', 'no-store');
    return res.sendFile(path.join(PUBLIC_DIR, pagina.file));
  }
  // Qualsiasi altro percorso che contiene ".htm" non viene servito (niente scorciatoie per le pagine protette).
  if (percorso.includes('.htm')) return res.status(404).sendFile(path.join(PUBLIC_DIR, 'login.html'));
  next();
});

// maxAge 0 + ETag: il browser ricontrolla i file, così le modifiche (es. nuove foto) si vedono subito.
app.use(express.static(PUBLIC_DIR, { index: false, maxAge: 0 }));

app.use((req, res) => {
  // Percorsi sconosciuti: le "pagine" tornano alla home, i file mancanti danno 404.
  if (path.extname(req.path)) return res.status(404).type('text').send('File non trovato');
  res.redirect('/');
});

// Errori (es. JSON malformato)
app.use((err, _req, res, _next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ errore: 'Richiesta non valida.' });
  if (err.type === 'entity.too.large') return res.status(413).json({ errore: 'Richiesta troppo grande.' });
  console.error(err);
  res.status(500).json({ errore: 'Errore del server. Riprova tra poco.' });
});

app.listen(PORT, () => {
  console.log(`\n  Duca Merch è attivo su  http://localhost:${PORT}`);
  console.log(`  Dominio email ammesso:  @${DOMINIO_EMAIL}`);
  console.log(`  Area admin:             ${ADMIN_PASSWORD ? `http://localhost:${PORT}/admin.html` : 'DISATTIVATA (imposta ADMIN_PASSWORD in .env)'}`);
  console.log(`  Prodotti a catalogo:    ${PRODOTTI.length}\n`);
});
