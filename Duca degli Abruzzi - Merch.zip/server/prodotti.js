'use strict';

/*
 * Catalogo del merch.
 * È l'UNICA fonte di verità: il server lo usa per validare i preordini e
 * calcolare i prezzi, il front-end lo riceve da /api/prodotti.
 *
 * Per aggiungere le foto vere:
 *   - metti i file in public/img/prodotti/
 *   - imposta `immagine` (foto generica) e/o `immagini` (una foto per colore), es:
 *       immagine: 'img/prodotti/felpa-uomo.jpg',
 *       immagini: { nero: 'img/prodotti/felpa-uomo-nero.jpg' }
 *   Se non c'è una foto, il sito disegna un'illustrazione del capo nel colore scelto.
 */

const TAGLIE = ['XS', 'S', 'M', 'L', 'XL', 'XXL', '3XL'];
const TAGLIA_UNICA = ['Taglia unica'];

const COLORI = {
  nero:           { nome: 'Nero',            hex: '#1d1f1e' },
  bianco:         { nome: 'Bianco',          hex: '#f3f1ea' },
  grigio:         { nome: 'Grigio melange',  hex: '#9a9c9f' },
  'blu-elettrico':{ nome: 'Blu elettrico',   hex: '#2350d6' },
  'blu-notte':    { nome: 'Blu notte',       hex: '#1b2440' },
  'verde-bottiglia': { nome: 'Verde bottiglia', hex: '#1f4a35' },
  verde:          { nome: 'Verde',           hex: '#3f8a4b' },
  bordeaux:       { nome: 'Bordeaux',        hex: '#6a1f2d' }
};

const COLORI_FELPA = ['nero', 'bianco', 'blu-elettrico', 'blu-notte', 'verde-bottiglia', 'verde', 'bordeaux', 'grigio'];

const CATEGORIE = [
  {
    id: 'felpe',
    titolo: 'Felpa con cappuccio',
    forma: 'felpa',
    testo: 'Cappuccio ampio, tasca a marsupio e lo stemma ricamato sul petto. Morbida dentro, resistente fuori: quella che non toglierai più da ottobre a maggio.'
  },
  {
    id: 'tshirt',
    titolo: 'T-shirt',
    forma: 'tshirt',
    testo: 'Cotone pesante, taglio regolare e lo stemma della scuola. Per le uscite didattiche, le giornate in campo e tutto il resto.'
  },
  {
    id: 'berretti',
    titolo: 'Berretto in lana',
    forma: 'berretto',
    testo: 'Lana a coste con risvolto e patch con lo stemma. Per le mattine di nebbia padovana.'
  },
  {
    id: 'cappelli',
    titolo: 'Cappello con frontino',
    forma: 'cappello',
    testo: 'Sei pannelli, frontino curvo e stemma frontale. Il cappello da tenere nello zaino da aprile in poi.'
  }
];

// I prezzi sono in centesimi per evitare errori di arrotondamento.
const PRODOTTI = [
  {
    id: 'felpa-uomo',
    categoria: 'felpe',
    nome: 'Felpa con cappuccio (no zip)',
    variante: 'Uomo',
    prezzo: 2500,
    taglie: TAGLIE,
    colori: COLORI_FELPA,
    immagine: null,
    immagini: {}
  },
  {
    id: 'felpa-donna',
    categoria: 'felpe',
    nome: 'Felpa con cappuccio (no zip)',
    variante: 'Donna',
    prezzo: 2500,
    taglie: TAGLIE,
    colori: COLORI_FELPA,
    immagine: null,
    immagini: {}
  },
  {
    id: 'felpa-unisex',
    categoria: 'felpe',
    nome: 'Felpa con cappuccio (no zip)',
    variante: 'Unisex',
    prezzo: 2500,
    taglie: TAGLIE,
    colori: COLORI_FELPA,
    immagine: null,
    immagini: {}
  },
  {
    id: 'tshirt',
    categoria: 'tshirt',
    nome: 'T-shirt',
    variante: null,
    prezzo: 1000,
    taglie: TAGLIE,
    colori: ['nero', 'bianco', 'blu-elettrico', 'verde-bottiglia', 'grigio', 'bordeaux'],
    immagine: null,
    immagini: {}
  },
  {
    id: 'berretto-lana',
    categoria: 'berretti',
    nome: 'Berretto in lana',
    variante: null,
    prezzo: 1000,
    taglie: TAGLIA_UNICA,
    colori: ['nero', 'blu-notte', 'verde-bottiglia', 'bordeaux', 'grigio'],
    immagine: null,
    immagini: {}
  },
  {
    id: 'cappello-frontino',
    categoria: 'cappelli',
    nome: 'Cappello con frontino',
    variante: null,
    prezzo: 1000,
    taglie: TAGLIE,
    colori: ['nero', 'bianco', 'blu-notte', 'verde-bottiglia', 'bordeaux'],
    immagine: null,
    immagini: {}
  }
];

function trovaProdotto(id) {
  return PRODOTTI.find((p) => p.id === id) || null;
}

/** Versione del catalogo da mandare al browser (colori espansi con nome ed esadecimale). */
function catalogoPubblico() {
  return {
    categorie: CATEGORIE,
    prodotti: PRODOTTI.map((p) => ({
      ...p,
      forma: CATEGORIE.find((c) => c.id === p.categoria).forma,
      colori: p.colori.map((id) => ({ id, ...COLORI[id] }))
    }))
  };
}

module.exports = { TAGLIE, COLORI, CATEGORIE, PRODOTTI, trovaProdotto, catalogoPubblico };
