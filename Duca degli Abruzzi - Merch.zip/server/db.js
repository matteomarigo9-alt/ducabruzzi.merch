'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite'); // SQLite integrato in Node.js (>= 22.13): nessuna installazione extra

const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.join(__dirname, '..', 'data');

fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new DatabaseSync(path.join(DATA_DIR, 'merch.db'));

db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS utenti (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    nome            TEXT NOT NULL,
    cognome         TEXT NOT NULL,
    classe          TEXT NOT NULL,
    email           TEXT NOT NULL UNIQUE,
    creato_il       TEXT NOT NULL,
    ultimo_accesso  TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessioni (
    token_hash  TEXT PRIMARY KEY,
    utente_id   INTEGER NOT NULL REFERENCES utenti(id) ON DELETE CASCADE,
    scade_il    INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS ordini (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    utente_id   INTEGER NOT NULL REFERENCES utenti(id),
    totale      INTEGER NOT NULL,           -- centesimi
    note        TEXT NOT NULL DEFAULT '',
    stato       TEXT NOT NULL DEFAULT 'ricevuto', -- ricevuto | annullato
    creato_il   TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS righe_ordine (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    ordine_id        INTEGER NOT NULL REFERENCES ordini(id) ON DELETE CASCADE,
    prodotto_id      TEXT NOT NULL,
    prodotto_nome    TEXT NOT NULL,
    colore_id        TEXT NOT NULL,
    colore_nome      TEXT NOT NULL,
    taglia           TEXT NOT NULL,
    quantita         INTEGER NOT NULL CHECK (quantita > 0),
    prezzo_unitario  INTEGER NOT NULL       -- centesimi
  );

  CREATE INDEX IF NOT EXISTS idx_ordini_utente ON ordini(utente_id);
  CREATE INDEX IF NOT EXISTS idx_righe_ordine ON righe_ordine(ordine_id);
  CREATE INDEX IF NOT EXISTS idx_sessioni_scadenza ON sessioni(scade_il);
`);

/** Esegue fn dentro una transazione: o va tutto a buon fine, o non viene salvato niente. */
function transazione(fn) {
  db.exec('BEGIN');
  try {
    const risultato = fn();
    db.exec('COMMIT');
    return risultato;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

module.exports = { db, transazione, DATA_DIR };
